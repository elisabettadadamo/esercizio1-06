let input = document.getElementById('clicca');
input.addEventListener('click', Show);
let titolo = document.getElementById('titolo')
titolo.style.display = 'none'




function Show(){
    fetch('https://jsonplaceholder.typicode.com/users')
  .then(res=> res.json())
  .then(res =>{
      console.log(res)
      input.style.display = 'none'
      titolo.style.display = ''
      
      let table = document.createElement('table');
            table.classList.add('table')
            let thead = document.createElement('thead');
            let tbody = document.createElement('tbody');
            let row1 = document.createElement('tr');
            let heading1 = document.createElement('th');
            heading1.innerHTML = "NAME";
            let heading2 = document.createElement('th');
            heading2.innerHTML = "USERNAME";
            let heading3 = document.createElement('th');
            heading3.innerHTML = "EMAIL";
            let heading4 = document.createElement('th');
            heading4.innerHTML = "WEBSITE"
            let heading5 = document.createElement('th');
            heading5.innerHTML = "ID"
            row1.append(heading1,heading2,heading3,heading4,heading5);
            thead.append(row1);
            heading1.classList.add("blu")
            heading2.classList.add("blu")
            heading3.classList.add("blu")
            heading4.classList.add("blu")
            heading5.classList.add("blu")
            



        res.forEach(tasks => {
            
            
            let row2 = document.createElement('tr');
            let row2Data1 = document.createElement('td');
            row2Data1.innerHTML = tasks.name;
            let row2Data2 = document.createElement('td');
            row2Data2.innerHTML = tasks.username;
            let row2Data3 = document.createElement('td');
            row2Data3.innerHTML = tasks.email;
            let row2Data4 = document.createElement('td');
            row2Data4.innerHTML = tasks.website
            let row2Data5 = document.createElement('td')
            row2Data5.innerText =  tasks.id
            row2Data5.classList.add('bottone')
            row2.append(row2Data1,row2Data2,row2Data3,row2Data4,row2Data5);
            tbody.append(row2);

            table.append(thead,tbody);
            row1.append(heading1);
            row1.append(heading2);
            row1.append(heading3);
            row1.append(heading4);
            row1.append(heading5);
            thead.append(row1);

           let dettagli = row2Data5
           
           dettagli.addEventListener('click', Details)

           function Details(){
              
               let modale = document.createElement('div')
               modale.innerHTML = `
               <div class="modal" >
               <div class="modal-dialog">
                 <div class="modal-content">
                   <div class="modal-header">
                   <h5>${'DETTAGLI  ' +tasks.name.toUpperCase()}</h5>
                     <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                   </div>
                   <div class="modal-body">
                    <p>${'phone:  ' +tasks.phone}</p>
                    <p>${'street:  ' +tasks.address.street}</p>
                    <p>${'suite:  ' +tasks.address.suite}</p>
                    <p>${'city:  ' +tasks.address.city}</p>
                    <p>${'zipcode:  ' +tasks.address.zipcode}</p>
                    <p>${'name:  ' + tasks.company.name}</p>
                    <p>${'catchPhrase:  ' +tasks.company.catchPhrase}</p>
                    <p>${'bs:  '  +tasks.company.bs}</p>
                   </div>
                   <div class="modal-footer ">
                     <button type="button" class="btn btn-success" data-bs-dismiss="modal">Close</button>
                     
                   </div>
                 </div>
               </div>
             </div>

               `
               document.body.append(modale)

               let modalWrap = new bootstrap.Modal(modale.querySelector('.modal'));
               modalWrap.show()
           }
        });
        
      
        console.log(tbody)
        table.append(thead,tbody);
        document.querySelector('#tabella').append(table);
        
       
     
  })

   
  
}
